package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddcustomerPage {
	
	public WebDriver ldriver;
	
	public AddcustomerPage(WebDriver rdriver)
	{ ldriver=rdriver;
	PageFactory.initElements(ldriver,this);
		
		
	}
	
	By lnkCustomers_menu=By.xpath("//a[@href='#']//p[contains(text(),'Customers')]");
	By lnkCustomer_menuitem=By.xpath("//a[@href='/Admin/Customer/List']//p[contains(text(),'Customers')]");
	
	By btnAddnew=By.xpath("//a[@href='/Admin/Customer/Create']");
	
	By txtemail=By.xpath("//input[@id='Email']");
	
	By txtpassword=By.xpath("//input[@id='Password']");
	
	By txtFirstName=By.xpath("//input[@id='FirstName']");
	
	By txtLastName=By.xpath("//input[@id='LastName']");
	
	By rdmalegender=By.xpath("//input[@id='Gender_Male']");
	
	By rdfemalegender=By.xpath("//input[@id='Gender_Female']");
	
	By txtdob=By.xpath("//input[@id='DateOfBirth']");	
	
	By txtCompanyName=By.xpath("//input[@id='Company']");
	
	By taxexempt=By.xpath("//input[@id='IsTaxExempt']");
	
	By textnewsletter=By.xpath("//div[@role='listbox'][1]");
	By textnewsletterdrp1=By.xpath("//li[text()='Test store 2']");
	
	
	
	
	
	By txtcustomerRoles=By.xpath("//span[contains(text(),'Registered')]");
	
	By listofitemadministrator=By.xpath("(//*[@role=\"listbox\"])[3]");
	
	By listofforummoderators=By.xpath("//li[contains(text(),'Forum Moderators')]");
	
	By listofitemGuest=By.xpath("//li[contains(text(),'Guests')]");
	
	By listofitemRegistered=By.xpath("//li[contains(text(),'Registered')]");
	
	By listofitemVendor=By.xpath("//*[@id=\"SelectedCustomerRoleIds_listbox\"]/li[5]");
	
	
	By managerofVendor=By.xpath("//select[@name='VendorId']");
	
	
	
	By btnsave=By.xpath("//button[@name='save']");
	
	
	By txtareaadmincomment=By.xpath("//textarea[@class='form-control']");
	
	
	//action method
	
	public String getPageTitle() {
		return ldriver.getTitle();
	}
	
	public void clickoncutomermenu() {
		ldriver.findElement(lnkCustomers_menu).click();
		
	}
	
	public void clickoncustomenuitem() throws InterruptedException {
		new WebDriverWait(ldriver, 30).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/Admin/Customer/List']//p[contains(text(),'Customers')]")));// Expectedcondition for the element to be clickable
		ldriver.findElement(By.xpath("/html/body/div[3]/aside/div/div[4]/div/div/nav/ul/li[4]/ul/li[1]/a/i")).click();
		//ldriver.findElement(By.xpath("//a[@href='/Admin/Customer/List']//p[contains(text(),'Customers')]")).click();	
		
	//	ldriver.findElement(lnkCustomer_menuitem).click();
	}
	
	public void clickonbuttonaddnew() {
		ldriver.findElement(btnAddnew).click();
	}
	
	public void sendtxtemail(String email) {
		ldriver.findElement(txtemail).sendKeys(email);
	}
	
	public void sendtxtpassword(String password) {
		ldriver.findElement(txtpassword).sendKeys(password);
	}
	
	public void listofitemadministrator( ) throws Exception {
		Actions actions = new Actions(ldriver);
		ldriver.findElement(listofitemadministrator).click();
		Thread.sleep(500);
		actions.sendKeys(Keys.ENTER);
	}
	
	public void setcustomerRoles(String roles) throws InterruptedException {
		
		if(!roles.equals("Vendor"))//if role is vendor should not delete register as per 
		{
			ldriver.findElement(By.xpath("//ul[@id='SelectedCustomerRoleIds_taglist']"));
		}
		
		ldriver.findElement(txtcustomerRoles).click();
		
	WebElement listofitemVendor;
		
		Thread.sleep(3000);
		
		if (roles.equals("Administrators"))
		{
			listofitemVendor=ldriver.findElement(listofitemadministrator);
		}
		else if (roles.equals("moderator"))
		{
			listofitemVendor=ldriver.findElement(listofforummoderators);
		}
		else if (roles.equals("Guest"))
		{
			listofitemVendor=ldriver.findElement(listofitemGuest);
		}
		else if (roles.equals("Registered"))
		{
			listofitemVendor=ldriver.findElement(listofitemRegistered);
		}
		}
	
	
	
	public void manageofvendor() {
		ldriver.findElement(managerofVendor).click();
	}

	public void setmanagerofvendor( String Value ) {
	ldriver.findElement(listofitemVendor).click();
	
	
}
	
	public void setgender(String gender) {
		
		if(gender.equals("male"))
		{
		
		ldriver.findElement(rdmalegender).click();
	}
		else if(gender.equals("female"))
		{
			ldriver.findElement(rdfemalegender).click();
		}
		else 
		{
			ldriver.findElement(rdmalegender).click();
		}
	}
	
	public void Lastnametext(String LastName) {
		ldriver.findElement(txtLastName).sendKeys("Lastname");
	}
	
	public void txtareaadmincomment(String textarea) {
		ldriver.findElement(txtareaadmincomment).sendKeys("this is a good company i am working here since 4 years\"");
	}
	
	public void savebutton() {
		ldriver.findElement(btnsave).click();
	}
	
	public void txtdob(String dob) {
		ldriver.findElement(txtdob).sendKeys("7/05/1993");
	}

	public void txtcompanyname(String cmpnyname) {
		ldriver.findElement(txtCompanyName).sendKeys(cmpnyname);
		
	}
	
	public void txtexempt() {
		ldriver.findElement(taxexempt).click();
	}
	
	
	public void txtnewsletter() {
		ldriver.findElement(textnewsletter).click();
	}
	
	
	
	public void textnewsletterdrp1() {
		ldriver.findElement(textnewsletterdrp1).click();
	}
	
	public void firsttextname(String firstname) {
		ldriver.findElement(txtFirstName).sendKeys("firstname");
	}
	
	
	public void txtcustomerRoles() {
		ldriver.findElement(txtcustomerRoles).click();
	}
	
	
	
		
        //Robot robot = new Robot();  	
        //robot.keyPress(KeyEvent.VK_UP);  
        //robot.keyPress(KeyEvent.VK_ENTER);
	}
	
//	public void setmanagerofvendor( String Value ) {
//	Select drp=new Select(ldriver.findElement(SelectedCustomerRoleIds));
//	drp.selectByVisibleText(Value);
//	drp.selectByIndex(1);
//	}
	
	
	
	

	

	
		
	

	
		
	

	
		
	

	
		
	


	

