package Pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.WaitHelper;

public class SearchCustomerPage {
	
public  WebDriver ldriver;
WaitHelper waithelper;
	
	public   SearchCustomerPage(WebDriver rdriver )
	
	
	{
		 ldriver = rdriver;
		PageFactory.initElements(rdriver,this);
		waithelper=new WaitHelper(ldriver);
		
	}

	@FindBy(how=How.ID,using="SearchEmail")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"SearchFirstName\"]")
	@CacheLookup
	WebElement txtFirstName;
	
	@FindBy(how=How.NAME,using="SearchLastName")
	@CacheLookup
	WebElement txtLastName;
	
	@FindBy(how=How.ID,using="search-customers")
	@CacheLookup
	WebElement btnSearchCustomer;
	
	@FindBy(how=How.XPATH,using="//table[@aria-describedby='customers-grid_info']")
	@CacheLookup
	WebElement table;
	
	@FindBy(how=How.XPATH,using="//table[@role='grid']")
	@CacheLookup
	WebElement tableSearchResult;
	
	@FindBy(how=How.XPATH,using="//div[@Class='dataTables_scrollBody']//tbody/tr")
	@CacheLookup
	List<WebElement> tableRows;
	
	@FindBy(how=How.XPATH,using="//div[@Class='dataTables_scrollBody']//tbody/tr/td")
	@CacheLookup
	List<WebElement> tablecolumns;
	
	public void setemail(String email) {
		waithelper.WaitForElement(txtEmail, 30);
		txtEmail.clear();
		txtEmail.sendKeys(email);
	}
	
	public void setFirstName(String Fname) {
		WebDriverWait wait = new WebDriverWait(ldriver, 20);
	//	waithelper.WaitForElement(txtFirstName, 20);
		txtFirstName.clear();
		txtFirstName.sendKeys(Fname);
	}
	
	public void setLastName(String LName) {
		waithelper.WaitForElement(txtLastName, 30);
		txtLastName.clear();
		txtLastName.sendKeys(LName);
	}
	
	public void clicksearch() {
		btnSearchCustomer.click();
		waithelper.WaitForElement(btnSearchCustomer, 40);
	}
	
	public int getNumOfRows() {
		return(tableRows.size());
	}
	
	public int getNumOfColumn() {
		return(tablecolumns.size());
	}
	
	public boolean SearchCustomerByEmail(String email) {
		
		boolean flag=false;
		for(int i=1;i<=getNumOfRows();i++)
		{
			String emailid=table.findElement(By.xpath("//table[@id=\"customers-grid\"]/tbody/tr["+i+"]/td[2]")).getText();
		System.out.println("emailid");
		if (emailid.equals(email))
		{
			flag=true;
		}
		
		}
		return flag;
	}
	
public boolean SearchCustomerByName(String Name) {
		
		boolean flag=false;
		for(int i=1;i<=getNumOfRows();i++)
		{
			String name=table.findElement(By.xpath("//table[@id=\"customers-grid\"]/tbody/tr["+i+"]/td[3]")).getText();
			String names[]=Name.split(" ");
		System.out.println("emailid");
		if (names[0].equals("Victoria") && names[1].equals("Terces"))
		{
			flag=true;
		}
		
		}
		System.out.println(flag);
		return flag;
}}
