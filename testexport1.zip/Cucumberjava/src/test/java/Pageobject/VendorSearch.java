package Pageobject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Utilities.WaitHelper;

public class VendorSearch {
	
	public WebDriver ldriver;
	WaitHelper waithelper;
	


	
	@FindBy(how=How.XPATH,using="//a[@href='#']//p[contains(text(),'Customers')]")
	@CacheLookup
	WebElement lnkCustomers_menu;
	
	@FindBy(how=How.XPATH,using="//a[@href='/Admin/Vendor/List']//p[contains(text(),'Vendors')]")
	@CacheLookup
	WebElement lnkVendors_menu;
	
	@FindBy(how=How.NAME,using="SearchName")
	@CacheLookup
	WebElement Vendorname_box;
	
	@FindBy(how=How.XPATH,using="//input[@id='SearchEmail']")
	@CacheLookup
	WebElement vendoremail_box;
	
	@FindBy(how=How.XPATH,using="//button[@id='search-vendors']")
	@CacheLookup
	WebElement Vendor_searchbtn;
	
	@FindBy(how=How.XPATH,using="//div[@class='dataTables_scroll']")
	@CacheLookup
	WebElement table;
	
	@FindBy(how=How.XPATH,using="//div[@class='dataTables_scrollBody']")
	@CacheLookup
	WebElement tableSearchResult;
	
	@FindBy(how=How.XPATH,using="//table[@id='vendors-grid']//tbody//tr")
	@CacheLookup
	List<WebElement> tableRows;
	
	@FindBy(how=How.XPATH,using="//table[@id='vendors-grid']//tbody//tr//td")
	@CacheLookup
	List<WebElement> tablecolumns;
	
	@FindBy(how=How.XPATH,using="//a[@href='/Admin/Vendor/Create']")
	@CacheLookup
	WebElement AddNewVenBtn;
	
	//add new vendor
	@FindBy(how=How.XPATH,using="//input[@id='Name']")
	@CacheLookup
	WebElement NameField;
	
	@FindBy(how=How.XPATH,using="//iframe[@id='Description_ifr']")
	@CacheLookup
	WebElement descriptionField;
	
	@FindBy(how=How.XPATH,using="//input[@id='Email']")
	@CacheLookup
	WebElement EmailTextField;
	
	@FindBy(how=How.XPATH,using="//input[@id='Active']")
	@CacheLookup
	WebElement ActiveCheckbox;
	
	@FindBy(how=How.XPATH,using="//button[@name='save']")
	@CacheLookup
	WebElement Savebtn;
	public VendorSearch(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(ldriver, this);
		waithelper=new WaitHelper(ldriver);
	}
	
	
	
	public void setVendorClick() throws InterruptedException {
		lnkCustomers_menu.click();
		Thread.sleep(5000);
		lnkVendors_menu.click();
		
	}
	
	public void setvendor(String Vname) {
		waithelper.WaitForElement(Vendorname_box, 30);
		Vendorname_box.clear();
		Vendorname_box.sendKeys(Vname);
		
	}
	
	public void setemailbox(String emailidtemp){
		waithelper.WaitForElement(vendoremail_box,30);
		vendoremail_box.clear();
		vendoremail_box.sendKeys(emailidtemp);
		
	}
	 public void vendorsearch() {
		 Vendor_searchbtn.click();
		waithelper.WaitForElement(Vendor_searchbtn, 40);
	 }
	 public int getNumOfRows() {
			return(tableRows.size());
		}
		
		public int getNumOfColumn() {
			return(tablecolumns.size());
		}
		
		public boolean searchVendor(String Vname) {
			boolean flag=false;
			for(int i=1;i<=getNumOfRows();i++) {
				String Vnameid=table.findElement(By.xpath("//table[@id='vendors-grid']//tbody//tr[1]//td[1]")).getText();
				System.out.println(Vnameid);
				if(Vnameid.equals(Vname))
				{
					flag= true;
				}
			}
				return flag;
				
			
			
		}

		
		public boolean searchvendorbyemail(String emailidtemp) {
			boolean flag=false;
			for(int i=1;i<=getNumOfRows();i++) {
				String emailid=table.findElement(By.xpath("//table[@id='vendors-grid']//tbody//tr[1]//td[2]")).getText();
				System.out.println(emailid);
				if(emailid.equals(emailidtemp))
						{
					flag=true;
						}
			}
			return flag;
			
		}
		
		public void ClickAddnewbtn() {
			AddNewVenBtn.click();
			ldriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
		
		public void addNewVenEnterName() {
			NameField.sendKeys("Satyam Gupta");
			}
		
		
		public void EnteringEmail( String gmail) {
			EmailTextField.sendKeys(gmail);
			}
		
		
		
		public void savebtn() {
			Savebtn.click();
			
		}
		
}
