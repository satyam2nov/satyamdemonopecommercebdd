package Utilities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class WaitHelper {
	
public  WebDriver driver;
	
	public   WaitHelper(WebDriver driver)
	
	{
		 this.driver=driver;
		
		}
	
	public void WaitForElement(WebElement element,long timeoutInSeconds) {
		WebDriverWait wait=new WebDriverWait(driver,timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	public void javascriptexecutermethod(WebDriver driver,WebElement element) {
		JavascriptExecutor js= ((JavascriptExecutor)driver);
		js.executeScript("argument[0].click()",element);
		
	}
	
}
