package TestRunner;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;



@RunWith(Cucumber.class)
@CucumberOptions
(
	features="src/test/java/feature/Vendor.feature",
	glue="StepDefinition_1",
	
	dryRun=false,
	monochrome=true,
	plugin= {"pretty","html:test-output"},
	tags= {"@Regression,@sanity"}
		)

public class TestRun {

}
