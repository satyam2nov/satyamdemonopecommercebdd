package StepDefinition_1;

import java.util.logging.Logger;

public class TestLog4J extends BaseClase {
	   Logger logger = Logger.getLogger(BaseClase.class.getName());
	   
	   public void childLog() {
		   logger.info("Child logger message");
		   logger.warning("Hi satyam this is warning");
	      }

	   

	
}