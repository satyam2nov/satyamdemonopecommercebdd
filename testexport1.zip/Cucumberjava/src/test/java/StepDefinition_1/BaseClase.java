package StepDefinition_1;
import java.util.Properties;
import java.util.logging.*;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;

import Pageobject.AddcustomerPage;
import Pageobject.LoginPage;
import Pageobject.SearchCustomerPage;
import Pageobject.VendorSearch;
  
public class BaseClase {
	public WebDriver driver;
	public LoginPage lp;
	public AddcustomerPage addcust;
	public SearchCustomerPage SearchCust;
	public VendorSearch VenSearch;
	public  Properties configProp;
	
	public static Logger Test;
	
	public static void main( String[] args ) {
		TestLog4J obj= new  TestLog4J();
		obj.childLog();
	}
	
	
	public static String randomstring(){
		String generatedString1=RandomStringUtils.randomAlphabetic(5);
		return(generatedString1);
	}
}
