
package StepDefinition_1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import Pageobject.AddcustomerPage;
import Pageobject.LoginPage;
import Pageobject.SearchCustomerPage;
import Pageobject.VendorSearch;
import Utilities.WaitHelper;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;


import java.util.logging.Logger;

//(//driver//chromedriver.exe)
//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//driver//chromedriver.exe");




public class Step1 extends BaseClase {
	Logger logger = Logger.getLogger(BaseClase.class.getName());



	
	@Before
	public void setup() throws IOException {	
		
	//	Logger logger = Logger.getLogger(BaseClase.class.getName());
		
		configProp=new Properties();
		FileInputStream configPropfile=new FileInputStream("Config.Properties");
		configProp.load(configPropfile);
		

		String br=configProp.getProperty("browser");
		
		if(br.equals("chrome")) {
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//driver//chromedriver.exe");
		driver=new ChromeDriver();
		}
		
		else if(br.equals("firefox")) {
			
			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"//driver//geckodriver.exe");
			driver=new FirefoxDriver();
			}
		
else if(br.equals("IE")) {
			
			System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+"//driver//IEDriverServer.exe");
			driver=new InternetExplorerDriver();
			}
else if(br.equals("Edge")) {
	
	System.setProperty("webdriver.edge.driver",System.getProperty("user.dir")+"//driver//msedgedriver.exe");
	driver=new EdgeDriver();
	}
		
		  logger.info("__________________Googlelaunchingchromebrowser_________________");
		  }
	
	@Given("^User Launch Chrome browser$")
public void user_Launch_Chrome_browser() throws Throwable {

		lp=new LoginPage(driver);
	driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	
  
}
	

@When("^User opens URL \"([^\"]*)\"$")

public void user_opens_URL(String url) throws Throwable {

	driver.get(url);
	logger.info("-------------------------this is openning url------------------------------");
	
}


@When("^User Enters Email as \"([^\"]*)\" and password as \"([^\"]*)\"$")
public void user_Enters_Email_as_and_password_as(String Email, String pwd) throws Throwable {
	lp.setUserName(Email);
   lp.setPassword(pwd);
   driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
   logger.info("---when user enters emails and password---");
   
   

}



@When("^Click on Login button$")
public void click_on_Login_button() throws Throwable {
	lp.clickLogin();
	logger.info("------------------when user click on login button-----");
  
}

@Then("^Page Title should be \"([^\"]*)\"$")
public void page_Title_should_be(String title) throws Throwable {
	if(driver.getPageSource().contains("Login was unsuccessful.")) {
		driver.close();
		Assert.assertTrue(false);
	}
		else {
			
					Assert.assertEquals(title, driver.getTitle());
					}
	logger.info("--------------------Page title verification------------------------");
}

	
   


@When("^User click on logout link$")
public void user_click_on_logout_link() throws Throwable {
	lp.clickLogout();
	Thread.sleep(3000);
}
    


@Then("^page Title Should be \"([^\"]*)\"$")
public void page_Title_Should_be(String arg1) throws Throwable {
   
}

@Then("^Close Browser$")
public void close_Browser() throws Throwable {
	driver.quit();
   
}

//Customer feature


@Then("^user can view dashboard$")
public void user_can_view_dashboard() throws Throwable {
	
	addcust=new AddcustomerPage(driver);
	Assert.assertEquals("Dashboard / nopCommerce administration", addcust.getPageTitle());
	Thread.sleep(3000);
   
}

@When("^User click on Customer menu$")
public void user_click_on_Customer_menu() throws Throwable {
	Thread.sleep(3000);
	
	addcust.clickoncutomermenu();
	logger.info("------------when user clicks on customer menu--------------------");
  
}

@When("^Click on Customer menu item$")
public void click_on_Customer_menu_item() throws Throwable {
	Thread.sleep(3000);
	addcust.clickoncustomenuitem();
	logger.info("----------------when user click on customer menu items----------------------");
  
}

@When("^Click on Add new button$")
public void click_on_Add_new_button() throws Throwable {
	addcust.clickonbuttonaddnew();
	Thread.sleep(3000);
	logger.info("--------------when user click on the add new button-------------");
 
}

@Then("^user can view add new customer page$")
public void user_can_view_add_new_customer_page() throws Throwable {
	Assert.assertEquals("Add a new customer / nopCommerce administration",addcust.getPageTitle());
	logger.info("--------------when user can add new customer page-------------------------");
  
}

@When("^user enter customer info$")
public void user_enter_customer_info() throws Throwable {
	
	String email=randomstring()+"@gmail.com";
	addcust.sendtxtemail(email);
	addcust.sendtxtpassword("test@123");
	addcust.listofitemadministrator();
	Thread.sleep(3000);
	
	
	
	
	addcust.setmanagerofvendor("vendor 2");
	addcust.setgender("male");
	addcust.firsttextname("satyam");
	addcust.Lastnametext("Gupta");
	addcust.txtdob("7/05/1985");
	addcust.txtcompanyname("STPL");
	addcust.txtareaadmincomment("This is a test comment...........");
	
	addcust.txtnewsletter();
	addcust.textnewsletterdrp1();
	logger.info("--------------when user enters the customer info-------------------------");

   
}

@When("^Click on save button$")
public void click_on_save_button() throws Throwable {
	addcust.savebutton();
	Thread.sleep(3000);
	logger.info("-------------when user click on the save button----------------");
  
}

@Then("^user can view confirmation message \"([^\"]*)\"$")
public void user_can_view_confirmation_message(String arg1) throws Throwable {
	Assert.assertTrue(driver.findElement(By.tagName("body")).getText().contains("The new customer has been added successfully."));
   logger.info("--------------when user can view the confirmation message-----------------");
}


@Then("^close browser$")
public void close_browser() throws Throwable {
	logger.info("-------------when user closed the browser------------------");
    
}

// Searching a Customer Using Emailid



@When("^Enter Customer Email$")
public void enter_Customer_Email() throws Throwable {
	
	SearchCust=new SearchCustomerPage(driver);
	SearchCust.setemail("victoria_victoria@nopCommerce.com");
	logger.info("----------------when user enter the customer emiails---------------------");
	}

@When("^Click on Search button$")
public void click_on_search_Button() throws Throwable {
	SearchCust.clicksearch();
	Thread.sleep(3000);
	logger.info("---------------when user click on the search button-----------------");
 
}

@Then("^User should found Email in search table$")
public void user_should_found_Email_in_search_table() throws Throwable {
	boolean status=SearchCust.SearchCustomerByEmail("victoria_victoria@nopCommerce.com");
	Assert.assertEquals(true, status);
	logger.info("----------------when user found email in search table---------------");
   
}

//steps for Searching a customer by First Name and LastName

@When("^Enter Customer First Name$")
public void enter_Customer_First_Name() throws Throwable {
	SearchCust=new SearchCustomerPage(driver);
	SearchCust.setFirstName("Victoria");
	logger.info("---------------when user enter the customer first name---------------");
   }

@When("^Enter Customer Last Name$")
public void enter_Customer_Last_Name() throws Throwable {
	SearchCust.setLastName("Terces");
	logger.info("-------------when user enter the customer last name-----------------");
	}

@Then("^User should found Name in search table$")
public void user_should_found_Name_in_search_table() throws Throwable {
	boolean status=SearchCust.SearchCustomerByName("Victoria Terces");
	Assert.assertEquals(true, status);
	logger.info("-------------when user found name in search table----------------------");
    
}

//Step for searching the vendor name


@And("^Click on Vendor menu item$")
public void click_on_Vendor_menu_item() throws Throwable {
	 VenSearch=new VendorSearch(driver);
	VenSearch.setVendorClick();
	logger.info("------------when user click on the vendor menu item----------------------");
	
}

@And("^Enter the Vendor name$")
public void enter_the_Vendor_name() throws Throwable {
	VenSearch=new VendorSearch(driver);
	VenSearch.setvendor("Vendor 1");
    logger.info("---------------when user enter the vendor name--------------------");
}

@When("^Click on the Search button$")
public void click_on_the_Search_button() throws Throwable {
	VenSearch.vendorsearch();
	Thread.sleep(5000);
	logger.info("-----------------when user click on the search button-------------------------");
    
}

@Then("^User should found the vendor name in the list$")
public void user_should_found_the_vendor_name_in_the_list() throws Throwable {
	boolean status=VenSearch.searchVendor("Vendor 1");
	Assert.assertEquals(true, status);
	logger.info("-------------------when user found the vendorname in the list---------------");
    
}

// steps for searching the vendor by emailid

@And("^Enter the Vendor Emailid$")
public void enter_the_Vendor_Emailid() throws Throwable {
	VenSearch=new VendorSearch(driver);
	VenSearch.setemailbox("vendor1email@gmail.com");
	logger.info("-----------------Entering the vendor Email id-----------------");
    }

@Then("^User should found the vendor Emailid in the list$")
public void user_should_found_the_vendor_Emailid_in_the_list() throws Throwable {
	boolean status=VenSearch.searchvendorbyemail("vendor1email@gmail.com");
	Assert.assertEquals(true, status);
	logger.info("--------------------------when user found email in the emaillist-------------------------");
   
}

// Steps for Add new Vendor


@When("^Click on the Add new button$")
public void click_on_the_Add_new_button() throws Throwable {
	VenSearch=new VendorSearch(driver);
	VenSearch.ClickAddnewbtn();
  
}

@Then("^Enter the Vendor info$")
public void enter_the_Vendor_info() throws Throwable {
	//driver.switchTo().frame("Description_ifr");
	VenSearch=new VendorSearch(driver);
	//driver.switchTo().defaultContent();
	VenSearch.addNewVenEnterName();
	logger.info("---------Entering vendor name----------------");
	
	//scrolling down the page
	JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;    
	jsExecutor.executeScript("window.scrollBy(0,350)", "");
	
	
	//sikuli using for description box
	
	Screen s=new Screen();
	Pattern psimg=new Pattern("C:\\Users\\satya\\eclipse-workspace\\Cucumberjava\\target\\descriptionbox.jpeg");
	s.wait(psimg,2000);
	s.type(psimg,"infomation has been conveyed to PIA" );
	logger.info("-----------------entering content in description box---------------------");
	
	String gmail=randomstring()+"@gmail.com";
	VenSearch.EnteringEmail(gmail);
	
	
	//Search.javascriptexecutercheckbox(ActiveCheckbox,javascript );	
	
	WebElement ActiveCheckbox = driver.findElement(By.id("Active"));   
	

	String javascript = "arguments[0].click()";      

	JavascriptExecutor jsExecutor1 = (JavascriptExecutor) driver;        

	jsExecutor1.executeScript(javascript, ActiveCheckbox);
	

                    

	
	logger.info("-------------Check the active box--------------");
	
	}

@Then("^Click on the Save button$")
public void click_on_the_Save_button() throws Throwable {
	VenSearch=new VendorSearch(driver);	
	VenSearch.savebtn();
	
	//verifying the alert message
	
	
	WebElement alertconetnt=driver.findElement(By.cssSelector(".alert.alert-danger.alert-dismissable"));
	String alertMessage = alertconetnt.getText();
	System.out.println(alertMessage.length());
	System.out.println(alertMessage.substring(2, 90));
	String alertMessageSubString = alertMessage.substring(2,90);
	String ActualMessage="For security purposes, the feature you have requested is not available on the demo site."	;
	 Assert.assertEquals(alertMessageSubString, ActualMessage);
   
}
//Check the functionality of ActivityLog
@When("^Click on ActivityLog$")
public void click_on_ActivityLog() throws Throwable {
    
}

@When("^Enter the Created from$")
public void enter_the_Created_from() throws Throwable {
  
}

@When("^Enter the Created to$")
public void enter_the_Created_to() throws Throwable {
  
}

@Then("^Click on the search button$")
public void click_on_the_search_button() throws Throwable {
    
}
	

}
