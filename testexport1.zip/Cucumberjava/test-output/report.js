$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/feature/Vendor.feature");
formatter.feature({
  "line": 1,
  "name": "Customers",
  "description": "",
  "id": "customers",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2409737800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "below are the common steps for each scenario//one space is required after writing background",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "User Launch Chrome browser",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "User opens URL \"https://admin-demo.nopcommerce.com/login?ReturnUrl\u003d%2Fadmin%2F\"",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "User Enters Email as \"admin@yourstore.com\" and password as \"admin\"",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "Click on Login button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "user can view dashboard",
  "keyword": "Then "
});
formatter.match({
  "location": "Step1.user_Launch_Chrome_browser()"
});
formatter.result({
  "duration": 459288500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://admin-demo.nopcommerce.com/login?ReturnUrl\u003d%2Fadmin%2F",
      "offset": 16
    }
  ],
  "location": "Step1.user_opens_URL(String)"
});
formatter.result({
  "duration": 2071410300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin@yourstore.com",
      "offset": 22
    },
    {
      "val": "admin",
      "offset": 60
    }
  ],
  "location": "Step1.user_Enters_Email_as_and_password_as(String,String)"
});
formatter.result({
  "duration": 350061500,
  "status": "passed"
});
formatter.match({
  "location": "Step1.click_on_Login_button()"
});
formatter.result({
  "duration": 6435574000,
  "status": "passed"
});
formatter.match({
  "location": "Step1.user_can_view_dashboard()"
});
formatter.result({
  "duration": 3019999800,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Search Vendor by Name",
  "description": "",
  "id": "customers;search-vendor-by-name",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@sanity"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "User click on Customer menu",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Click on Vendor menu item",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Enter the Vendor name",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Click on the Search button",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "User should found the vendor name in the list",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Step1.user_click_on_Customer_menu()"
});
formatter.result({
  "duration": 3138902600,
  "status": "passed"
});
formatter.match({
  "location": "Step1.click_on_Vendor_menu_item()"
});
formatter.result({
  "duration": 7474957000,
  "status": "passed"
});
formatter.match({
  "location": "Step1.enter_the_Vendor_name()"
});
formatter.result({
  "duration": 339564300,
  "status": "passed"
});
formatter.match({
  "location": "Step1.click_on_the_Search_button()"
});
formatter.result({
  "duration": 151597000,
  "status": "passed"
});
formatter.match({
  "location": "Step1.user_should_found_the_vendor_name_in_the_list()"
});
formatter.result({
  "duration": 125577800,
  "status": "passed"
});
formatter.match({
  "location": "Step1.close_Browser()"
});
formatter.result({
  "duration": 779331900,
  "status": "passed"
});
});